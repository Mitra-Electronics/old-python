---
title: How to add a new payment processor
linktitle: Add payment processor
description: This guide will explain the steps of adding a new payment processor to Silver.
keywords: [silver, guide, payment, processor]
---

---
title: Guides
linktitle: Guides
description: We have put together some useful guides to help you better understand how Silver works and how you can easily add your own functionalities.
keywords: [silver, guide, payment, processor]
---

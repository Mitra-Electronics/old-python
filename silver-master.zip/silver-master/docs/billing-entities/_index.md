---
title: Billing Entities
linktitle: Billing Entities
description: "The two billing entities are the provider (the person that offers a certain service or product) and the customer (the person who benefits from the service or product)."
keywords: [silver]
---

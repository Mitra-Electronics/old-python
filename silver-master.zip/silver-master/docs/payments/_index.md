---
title: Payments
linktitle: Payments
description: Silver contains complex payment handling that includes payments, payment methods, payment processors and transactions.
keywords: [silver]
---

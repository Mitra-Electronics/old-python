---
title: Billing Units
linktitle: Billing Units
description: The billing units that silver offers are the billing plan and the subscription, which allows to connect a customer to a plan.
keywords: [silver]
---

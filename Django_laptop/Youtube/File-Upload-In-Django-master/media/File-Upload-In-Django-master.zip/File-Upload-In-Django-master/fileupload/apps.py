from django.apps import AppConfig


class FileuploadConfig(AppConfig):
    name = 'fileupload'

from django.apps import AppConfig


class StreamAppConfig(AppConfig):
    name = 'stream_app'

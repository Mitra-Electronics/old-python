﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","pl",{title:"Informacja o elemencie",dialogName:"Nazwa okna dialogowego",tabName:"Nazwa zakładki",elementId:"ID elementu",elementType:"Typ elementu"});
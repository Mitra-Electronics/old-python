﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","pt-br",{button:"Inserir fragmento de código",codeContents:"Conteúdo do código",emptySnippetError:"Um fragmento de código não pode ser vazio",language:"Idioma",title:"Fragmento de código",pathName:"fragmento de código"});